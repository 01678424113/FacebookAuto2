<?php $__env->startSection('content'); ?>
    <div class="col-md-10">
        <div class="content-right">
            <h3 class="title-content-right">Sửa page : <?php echo e($group->group_name); ?></h3>
            <form class="form-horizontal" action="<?php echo e(route('postEditGroup',$group->id)); ?>" method="post">
                <?php echo e(csrf_field()); ?>

                <div class="form-group">
                    <label class="control-label col-sm-2" for="group_id">Id:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="group_id"  name="group_id" readonly value="<?php echo e($group->group_id); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="group_name">Name:</label>
                    <div class="col-sm-10">
                        <input type="text" class="form-control" id="group_name" name="group_name" placeholder="Nhập name group" value="<?php echo e($group->group_name); ?>">
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-sm-2" for="id_category">Category:</label>
                    <div class="col-sm-10">
                        <select name="id_category" id="id_category" class="form-control">
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option <?php if($group->id_category == $category->id): ?>
                                        <?php echo e("selected"); ?>

                                        <?php endif; ?>
                                        value="<?php echo e($category->id); ?>"><?php echo e($category->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-2 col-sm-10">
                        <button type="submit" class="btn btn-default">Sửa</button>
                    </div>
                </div>
            </form>
        </div>
        <?php if(session('error')): ?>
            <div class="alert alert-danger">
                <strong><?php echo e(session('error')); ?></strong>
            </div>
        <?php endif; ?>
        <?php if(count($errors) >0): ?>
            <div class="alert alert-danger">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $err): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <strong><?php echo e($err); ?></strong>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>