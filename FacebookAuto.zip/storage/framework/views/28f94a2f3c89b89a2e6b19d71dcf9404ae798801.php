<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-5 col-md-offset-2">
                <h3>Đăng nhập bằng tài khoản Facebook</h3>
                <form action="<?php echo e(route('postAccessTokenFull')); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <label for="username">Tên đăng nhập :</label>
                        <input type="text" class="form-control" name="username" id="username" placeholder="Tên đăng nhập facebook">
                    </div>
                    <div class="form-group">
                        <label for="password">Mật khẩu:</label>
                        <input type="password" class="form-control" id="password" name="password">
                    </div>
                    <button id="click" type="submit" class="btn btn-default">Đăng nhập</button>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>