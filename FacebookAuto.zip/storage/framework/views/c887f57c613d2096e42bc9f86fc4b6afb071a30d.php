<?php $__env->startSection('content'); ?>
    <?php if(empty($user->access_token_full) &&  Session::get('id_user')): ?>
        <div class="col-md-6 col-md-offset-3 text-center">
            <p class="alert alert-warning" style="color: black">Bạn cần lấy access token full quyền để thực hiện được
                đầy đủ các chức năng. Click dưới để tiếp tục</p>
            <div class="btn btn-default"><a href="<?php echo e(route('getAccessTokenFull')); ?>">Click now</a></div>
        </div>
    <?php elseif(!empty($user->access_token_full)): ?>
        <div class="col-md-6 col-md-offset-3 alert alert-success ">
            <p style="color: black">Lấy access token full quyền thành công. Bạn có thể sử dụng các tính năng chúng tôi cung cấp !</p>
            <hr>
            <strong>Các tính năng nổi bật :</strong>
            <ul>
                <li>Tự động đăng bài lên page .</li>
                <li>Tự động đăng bài lên group .</li>
                <li>Tự động kết bạn .</li>
                <li>Và nhiều tính năng khác ... </li>
            </ul>
        </div>
    <?php endif; ?>
    <?php if(empty(Session::get('id_user'))): ?>
        <div class="container">
            <div class="row">
                <div class="col-md-5 col-md-offset-2 alert alert-warning">
                    <p>Không cần đăng kí. Bạn có thể đăng nhập ngay bằng tài khoản FaceBook , Gmail hoặc Twiter. Click dưới đây !!</p>
                    <hr>
                    <form style="text-align: center">
                       
                        <a class="btn btn-info" href="<?php echo e($login_url); ?>">FaceBook</a>
                        <a class="btn btn-danger" href="<?php echo e($login_url); ?>">Gmail</a>
                        <a class="btn btn-default" href="<?php echo e($login_url); ?>">Twiter</a>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>