<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="content-right show-group">
            <h3 class="title-content-right">Danh sách group</h3>
            <hr>
            <table class="table-hover" style="width: 100%">
                <tr>
                    <td>ID</td>
                    <td>Post ID</td>
                    <td>Người đăng</td>
                </tr>

            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td><?php echo e($post->post_id); ?></td>
                        <td><?php echo e($post->users->name); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-info btn-add"><a href="<?php echo e(route('getAddGroup')); ?>">Add group</a></button>
        </div>
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(session('message')); ?></strong>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>