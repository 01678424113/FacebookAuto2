<?php $__env->startSection('content'); ?>
    <div class="col-md-12">
        <div class="content-right show-page">
            <h3 class="title-content-right">Danh sách page</h3>
            <hr>
            <table class="table-hover" style="width: 100%">
                <tr>
                    <td>ID</td>
                    <td>Id page</td>
                    <td>Name page</td>
                    <td>Category page</td>
                    <td></td>
                    <td></td>
                </tr>
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($page->id); ?></td>
                        <td><?php echo e($page->page_id); ?></td>
                        <td><?php echo e($page->page_name); ?></td>
                        <td><?php echo e($page->category->name); ?></td>
                        <td>
                            <button class="btn btn-info"><a href="<?php echo e(route('getEditPage',$page->id)); ?>">Edit</a></button>
                        </td>
                        <td>
                            <button class="btn btn-danger"><a href="<?php echo e(route('deletePage',$page->id)); ?>">Delete</a></button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <button class="btn btn-info btn-add"><a href="<?php echo e(route('getAddPage')); ?>">Add page</a></button>
        </div>
        <?php if(session('message')): ?>
            <div class="alert alert-success">
                <strong><?php echo e(session('message')); ?></strong>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>