<?php

session_start();
$fbData = array(
    'app_id' => '874373596059321',
    'app_secret' => '78935dae89f1369b79abb2bc812f80c6',
    'default_graph_version' => 'v2.2'
);

$fb = new Facebook\Facebook($fbData);
$helper = $fb->getRedirectLoginHelper();
try {
    $accessToken = $helper->getAccessToken();
    // OAuth 2.0 client handler
    $oAuth2Client = $fb->getOAuth2Client();

    // Exchanges a short-lived access token for a long-lived one
    $accessToken = $oAuth2Client->getLongLivedAccessToken($accessToken);
    $fb->setDefaultAccessToken($accessToken);
    $response = $fb->get('/me?feilds=email,name');
    $usernode= $response->getGraphUser();
    $user_name = $usernode->getName();

    setcookie("user_name",$user_name,time()+3600);
    setcookie("accessToken",$accessToken,time()+3600);
    header(route('home'));
} catch(Facebook\Exceptions\FacebookResponseException $e) {
    // When Graph returns an error
    echo 'Graph returned an error: ' . $e->getMessage();
    exit;
} catch(Facebook\Exceptions\FacebookSDKException $e) {
    // When validation fails or other local issues
    echo 'Facebook SDK returned an error: ' . $e->getMessage();
    exit;
}