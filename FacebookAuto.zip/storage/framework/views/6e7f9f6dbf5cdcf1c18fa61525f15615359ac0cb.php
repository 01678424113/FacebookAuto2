<?php
use Facebook\Authentication\AccessToken;
use Facebook\FacebookApp;
use Facebook\FacebookRequest;
session_start();
$fbData = array(
    'app_id' => '874373596059321',
    'app_secret' => '78935dae89f1369b79abb2bc812f80c6',
    /*'profile_id' => '{PAGE ID}',*/
    'default_graph_version' => 'v2.5',
);

$fb = new Facebook\Facebook($fbData);

$params = array('req_perms' => 'manage_pages, publish_pages, public_profile');
$helper = $fb->getRedirectLoginHelper();
$loginUrl = $helper->getLoginUrl('http://localhost:8000/call-back', $params);

header(route('callBack'));
exit;