<div class="footer text-center">
    <p>tool.shares.vn  - Everything is simple </p>
</div>