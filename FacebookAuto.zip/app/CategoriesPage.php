<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CategoriesPage extends Model
{
    protected $table = 'categories_pages';
    public $timestamps = false;

}
