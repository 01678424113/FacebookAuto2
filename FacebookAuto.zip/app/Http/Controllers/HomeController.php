<?php

namespace App\Http\Controllers;
use App\CategoriesPage;
use App\Page;
use App\User;
use Illuminate\Http\Request;
use Session;

class HomeController extends Controller
{

}
